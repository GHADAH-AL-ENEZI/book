var i =1;
class vehicle{

    constructor(ID , name_company , name){
                
        this.ID = ID
        this.name_company = name_company
        this.name = name
    }
}

class car extends vehicle{

    constructor(ID , name_company , name , type){
        super(ID , name_company , name)
        this.type = type
    }
}


class airplane extends vehicle{

    constructor(ID , name_company , name , type){
        super(ID , name_company , name)
        this.type = type
    }
}

class employee{
    constructor(ID , date , name){
        this.ID = ID
        this.date = date
        this.name = name
    }
}

class driver extends employee{

    constructor(ID , date  , name , licenseID){
        super(ID , date , name)
        this.licenseID = licenseID
    }
}


class pilot extends employee{

    constructor(ID , date  , name , licenseID){
        super(ID , date , name)
        this.licenseID = licenseID
    }
}

class  reserved{
    constructor(reservationDate , employeeID , vehiclesID , reservationID){
        this.reservationDate = reservationDate
        this.employeeID = employeeID
        this.vehiclesID = vehiclesID
        this.reservationID = reservationID
    }
}


var c1 = new car(1 , "bmw" , "bmw12" , "gas");
var c2 = new car(2 , "mercedes" , "m12" , "electic");
var c3 = new car(3 , "humer" , "humer12" , "gas");

var a1 = new airplane(4 , "a" , "aa" , "gas");
var a2 = new airplane(5 , "bb" , "bb" , "gas");


var d1 = new employee(1 , "2000" , "rahaf" , 1)
var d2 = new employee(3 , "1999" , "ahlam" , 3)

var p1 = new pilot(2 , "2000" , "maha" , 2)
var p2 = new pilot(4 , "2000" , "sham" , 4)


var arr = Array();


compare(2 , 1)

function compare(id_v ,id_e){

    if( (c1.ID == id_v && d1.ID == id_e ) || (c1.ID == id_v && d2.ID == id_e) || (c2.ID == id_v && d1.ID == id_e) || (c2.ID == id_v && d2.ID == id_e) || (c3.ID == id_v && d1.ID == id_e) || (c3.ID == id_v && d2.ID == id_e)){
        i++;
        arr.push(new  reserved(new Date().getFullYear(), id_e , id_v , i))
    }else if((a1.ID == id_v && p1.ID == id_e) || (a1.ID == id_v && p2.ID == id_e) || (a2.ID == id_v && p1.ID == id_e) || (a2.ID == id_v && p2.ID == id_e)){
        i++;
        arr.push(new  reserved(new Date().getFullYear() , id_e , id_v , i))
    }else {
        alert("غير متوافقين")
    }


}

const map = new Map(Object.entries(arr));

console.log(Object.fromEntries([...map]))