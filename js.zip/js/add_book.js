var arr_book = Array();


function add_book(){
    
    var tmp = false;
    var id = document.getElementsByName("id")[0].value;
    var title = document.getElementsByName("title")[0].value;
    var auth = document.getElementsByName("author")[0].value;
    var price = document.getElementsByName("price")[0].value;
    var quantity = document.getElementsByName("quantity")[0].value;

    var alert_add = document.getElementById("alert_add");

    for(i = 0 ; i < arr_book.length ; i++ ){
        if(id == arr_book[i][0]){
           
            tmp = true;
        }
    }

    if(tmp){
            
        var alert = '<div class="alert alert-danger alert-dismissible"><button type="button" class="btn-close" data-bs-dismiss="alert"></button><strong>faild!</strong> This ID is Exist.</div> ';
        alert_add.innerHTML=alert;
    }else{
            arr_book.push([id , title , auth , price , quantity]);
            var alert = '<div class="alert alert-success alert-dismissible"><button type="button" class="btn-close" data-bs-dismiss="alert"></button><strong>Sucess!</strong>.</div> ';
            alert_add.innerHTML=alert;
        }

        show_book();
 
}

function show_book(){

    var table = document.getElementById("tbody");
    table.innerHTML = ``;
    for(var i = 0 ; i < arr_book.length ; i++){

        table.innerHTML += `
        <tr>
                            <td>${arr_book[i][0]}</td>
                            <td>${arr_book[i][1]}</td>
                            <td>${arr_book[i][2]}</td>
                            <td>${arr_book[i][3]}</td>
                            <td>${arr_book[i][4]}</td>
                            <td>
                                <button  class="btn btn-warning"  data-bs-toggle="modal" data-bs-target="#update${i}">Update</button>
                                <div class=" modal" id="update${i}">
                                <div class=" modal-dialog">
                                    <div class=" modal-dialog">
                                        <div class=" modal-content">
                                            <div class=" modal-header">
                                                <h6>Update</h6>
                                            </div>
                                            <div class=" modal-body">

                                                <div class=" container" id="alert_update">

                                                </div>
                                                <div class=" form-floating my-4">
                                                    <input type="text" id="id_u${i}"  class=" form-control" placeholder=" " value="${arr_book[i][0]}">
                                                    <label for="">ID</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="title_u${i}"  class=" form-control" placeholder=" " value="${arr_book[i][1]}">
                                                    <label for="">Title</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="author_u${i}"  class=" form-control" placeholder=" " value="${arr_book[i][2]}">
                                                    <label for="">Author</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="price_u${i}"  class=" form-control" placeholder=" " value="${arr_book[i][3]}">
                                                    <label for="">Pric</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="quantity_u${i}"  class=" form-control" placeholder=" " value="${arr_book[i][4]}">
                                                    <label for="">Quantity</label>
                                                </div>

                                                <div class=" d-flex justify-content-center">
                                                    <button class="btn btn-dark" onclick="update_book(${i})">update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </td>
                            <td><button  class="btn btn-danger" onclick="delete_book(${i})">Delete</button></td>
                            <td>
                                <button  class="btn btn-dark"  data-bs-toggle="modal" data-bs-target="#pay${i}">pay</button>
                                <div class=" modal" id="pay${i}">
                                <div class=" modal-dialog">
                                    <div class=" modal-dialog">
                                        <div class=" modal-content">
                                            <div class=" modal-header">
                                                <h6>Pay</h6>
                                            </div>
                                            <div class=" modal-body">

                                                <div class=" container" id="alert_pay">

                                                </div>
                                                    
                                                <div class=" form-floating my-4">
                                                    <input type="text" id="quantity_pay${i}"  class=" form-control" placeholder=" " oninput="price_q(${i})">
                                                    <label for="">Quantity</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="price_pay${i}"  class=" form-control" placeholder=" " >
                                                    <label for="">Pric</label>
                                                </div>

                                              

                                                <div class=" d-flex justify-content-center">
                                                    <button class="btn btn-dark" onclick="pay_book(${i})">Pay</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </td>
                      
                        </tr>
        `
    }
}


function delete_book(index){

    
    arr_book.splice(index, 1);
    show_book();

}

function update_book(index){


    var id = document.getElementById('id_u'+index).value;
    var title = document.getElementById("title_u"+index).value;
    var auth = document.getElementById("author_u"+index).value;
    var price = document.getElementById("price_u"+index).value;
    var quantity = document.getElementById("quantity_u"+index).value;

    arr_book[index][0] = id;
    arr_book[index][1] = title;
    arr_book[index][2] = auth;
    arr_book[index][3] = price;
    arr_book[index][4] = quantity;

    show_book();

}


function seacrh(){

    var arr_tmp = Array()
    var seacrh = document.getElementsByName("search")[0].value;

    for(i =0 ; i< arr_book.length ; i++){

        if(arr_book[i][0] == seacrh || arr_book[i][1] == seacrh || arr_book[i][2] == seacrh){
            arr_tmp.push([arr_book[i][0] , arr_book[i][1] , arr_book[i][2] , arr_book[i][3] , arr_book[i][4]]);
        }
    }
    console.log(arr_tmp)


    var table = document.getElementById("tbody");
    table.innerHTML = ``;
    for(var i = 0 ; i < arr_tmp.length ; i++){

        table.innerHTML += `
        <tr>
                            <td>${arr_tmp[i][0]}</td>
                            <td>${arr_tmp[i][1]}</td>
                            <td>${arr_tmp[i][2]}</td>
                            <td>${arr_tmp[i][3]}</td>
                            <td>${arr_tmp[i][4]}</td>
                            <td>
                                <button  class="btn btn-warning"  data-bs-toggle="modal" data-bs-target="#update${i}">Update</button>
                                <div class=" modal" id="update${i}">
                                <div class=" modal-dialog">
                                    <div class=" modal-dialog">
                                        <div class=" modal-content">
                                            <div class=" modal-header">
                                                <h6>Update</h6>
                                            </div>
                                            <div class=" modal-body">

                                                <div class=" container" id="alert_update">

                                                </div>
                                                <div class=" form-floating my-4">
                                                    <input type="text" id="id_u${i}"  class=" form-control" placeholder=" " value="${arr_tmp[i][0]}">
                                                    <label for="">ID</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="title_u${i}"  class=" form-control" placeholder=" " value="${arr_tmp[i][1]}">
                                                    <label for="">Title</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="author_u${i}"  class=" form-control" placeholder=" " value="${arr_tmp[i][2]}">
                                                    <label for="">Author</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="price_u${i}"  class=" form-control" placeholder=" " value="${arr_tmp[i][3]}">
                                                    <label for="">Pric</label>
                                                </div>

                                                <div class=" form-floating my-4">
                                                    <input type="text" id="quantity_u${i}"  class=" form-control" placeholder=" " value="${arr_tmp[i][4]}">
                                                    <label for="">Quantity</label>
                                                </div>

                                                <div class=" d-flex justify-content-center">
                                                    <button class="btn btn-dark" onclick="update_book(${i})">update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </td>
                            <td><button  class="btn btn-danger" onclick="delete_book(${i})">Delete</button></td>
                        </tr>
        `
    }


}




function pay_book(index){


    var q = document.getElementById("quantity_pay"+index);

    
    
    var alert_pay = document.getElementById("alert_pay");

    
    if( parseFloat( q.value ) > parseFloat( arr_book[index][4])){
        
        var alert = `<div class="alert alert-danger alert-dismissible"><button type="button" class="btn-close" data-bs-dismiss="alert"></button><strong>faild!</strong> The quantity is bigger than the existing one.</div>`;
        alert_pay.innerHTML=alert;
    }else{
        arr_book[index][4] -=q.value;
        var alert = `<div class="alert alert-success alert-dismissible"><button type="button" class="btn-close" data-bs-dismiss="alert"></button><strong>sucess!</strong> .</div>`;
        alert_pay.innerHTML=alert;
    }
}


function price_q(index){
    

var q = document.getElementById("quantity_pay"+index);

var p = document.getElementById("price_pay"+index);

    p.value  = parseFloat(q.value) * parseFloat( arr_book[index][3]);

}